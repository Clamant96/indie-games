package com.exploregames.indieGames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndieGamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndieGamesApplication.class, args);
	}

}
