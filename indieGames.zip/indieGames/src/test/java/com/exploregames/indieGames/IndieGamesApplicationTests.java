package com.exploregames.indieGames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndieGamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
